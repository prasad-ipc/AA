
<div class="example">
    <ul id="nav">
	
		<li><a href="../whmcs/index.php">HOME</a></li>
		<li><a href="#">EDIT</a>

			<ul>
				<li><a href="edit_find_benf.php">EDIT BENEFICIARY</a></li>
				<li><a href="edit_find_nps.php">EDIT NPS</a></li>
				<li><a href="#">EDIT BC</a></li>
				<li><a href="#">EDIT DC</a></li>
				
			</ul>
		</li>
		<li><a >REPORTS</a>
			<ul>
				<li><a href="find_dis_swalambana.php">SWALAMBANA APPLICATIONS</a></li>
				<li><a href="#">AAM AADMI APPLICATIONS </a></li>
				<li><a href="#">E-INSURANCE APPLICATIONS</a></li>
				
			</ul>
		</li>
		<li><a href="#">ADD</a>
			<ul>
				<li><a href="addbenf.php">BENF DETAILS</a></li>
				<li><a href="add_swalambana_nos.php">SWALAMBANA NPS DAILY STATEMENT</a></li>
				<li><a href="#">AAM AADMI NPS DAILY STATEMENT</a></li>
				<li><a href="#">E-INSURANCE NPS DAILY STATEMENT</a></li>
			</ul>
		</li>
		<li><a href="#">MIS</a>

			<ul>
				<li><a href="find_mis_swalambana.php" target "_blank">SWALAMBANA</a></li>
				<li><a href="find_mis_aam_admi.php">AAM ADMI</a></li>
				<li><a href="#">E-INSURANCE</a></li>				
			</ul>
		</li>
		<li><a href="#">EMPLOYEES</a>
			<ul>
				<li><a href="find_employees.php">EMPLOYEES STATEMENT</a></li>
				<li><a href="add_dc.php">ADD DC</a></li>
				<li><a href="add_bc.php">ADD BC</a></li>
				<li><a href="add_nps.php">ADD NPS</a></li>
				
			</ul>
		</li>		
		<li><a href="#">FIND</a>
			<ul>
				<li><a href="find_dc.php">DC</a></li>
				<li><a href="find_bc.php">BC</a></li>
				<li><a href="find_nps.php">NPS</a></li>
				
			</ul>
		</li>
	</ul>
</div>
