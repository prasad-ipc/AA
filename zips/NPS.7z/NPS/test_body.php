<html>
<head>

<link rel="stylesheet" href="css/base.css"> 
<title>
</title>
<style type="text/css">

#test{
	  background:#fff url(images/clouds-in-blue-sky.jpg);
    width:60%;
    height:70px;
    border:1px #000 solid;
    margin:20px auto;
    padding:15px;
    border-radius:3px;
    -moz-border-radius:3px;
    -webkit-border-radius:3px;
}

</style>
</head>

<body>
<div id ="test"></div>

</body>
</html>
