<style type="text/css">


.navmenu, .navmenu ul{

}
.navmenu{
	text-align: center;
	background-color: #0000FF;
	margin-top: -23px;
	width: 100%;
 	height: 50px;

	}
	.navmenu ul a:hover{
		background-color: #2E64FE;
}

.navmenu ul a{
	width: 30px;
	height: 35px;
	color: white;
	padding: 8px 20px 8px 20px;
	font-size: 25px;
	background-color: #4000FF;
}
.navmenu ul{
	margin-top: 25px;
	padding: 12px;
}
</style>


<div class="navmenu">
	<ul>
	<a href="manage.php">Home</a>
	<a href="dist_app.php">District</a>
	<a href="block.php">Block</a>
	<a href="nps.php">NPS</a>
	<a href="application.php">Applicatios</a>
	<a href="mis.php">MIS</a>
	<a href="employees.php">Employees</a>
	<a href="addbenf.php">Add Beneficiary</a>
	</ul>

</div>
<nav>
	<ul>
		<li><a href="#">Home</a></li>
		<li><a href="#">Tutorials</a>
			<ul>
				<li><a href="#">Photoshop</a></li>
				<li><a href="#">Illustrator</a></li>
				<li><a href="#">Web Design</a>
					<ul>
						<li><a href="#">HTML</a></li>
						<li><a href="#">CSS</a></li>
					</ul>
				</li>
			</ul>
		</li>
		<li><a href="#">Articles</a>
			<ul>
				<li><a href="#">Web Design</a></li>
				<li><a href="#">User Experience</a></li>
			</ul>
		</li>
		<li><a href="#">Inspiration</a></li>
	</ul>
</nav>
