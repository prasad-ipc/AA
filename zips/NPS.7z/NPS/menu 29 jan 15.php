


<nav>
	<ul>
		<li><a href="../whmcs/index.php">Home</a></li>
		<li><a href="#">Edit</a>

			<ul>
				<li><a href="edit_find_benf.php">Edit Beneficiary</a></li>
				<li><a href="edit_find_nps.php">Edit NPS</a></li>
				<li><a href="#">Edit BC</a></li>
				<li><a href="#">Edit DC</a></li>
				
			</ul>
		</li>
		<li><a href="">Reports</a>
			<ul>
				<li><a href="find_app.php">Swalambana Applications</a></li>
				<li><a href="#">Aam Admi Applications </a></li>
				<li><a href="#">E-Insurance Applications</a></li>
				
			</ul>
		</li>
		<li><a href="#">Add</a>
			<ul>
				<li><a href="addbenf.php">Benf Details</a></li>
				<li><a href="addbenfnos.php">Swalambana NPS Daily statement</a></li>
				<li><a href="#">Aam Admi NPS Daily statement</a></li>
				<li><a href="#">E-Insurance NPS Daily statement</a></li>
			</ul>
		</li>
		<li><a href="#">MIS</a>

			<ul>
				<li><a href="find_mis_swalambana.php">Swalambana</a></li>
				<li><a href="find_mis_aam_admi.php">Aam Admi</a></li>
				<li><a href="#">E-Insurance</a></li>				
			</ul>
		</li>
		<li><a href="#">EMPLOYEES</a>
			<ul>
				<li><a href="find_employees.php">EMPLOYEES STATEMENT</a></li>
				<li><a href="add_dc.php">ADD DC</a></li>
				<li><a href="add_bc.php">ADD BC</a></li>
				<li><a href="add_nps.php">ADD NPS</a></li>
				
			</ul>
		</li>		
		<li><a href="#">FIND</a>
			<ul>
				<li><a href="find_dc.php">DC</a></li>
				<li><a href="find_bc.php">BC</a></li>
				<li><a href="find_nps.php">NPS</a></li>
				
			</ul>
		</li>
	</ul>
</nav>
