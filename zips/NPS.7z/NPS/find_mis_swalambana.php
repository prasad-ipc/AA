<?php 
session_start();
$_SESSION['project']='SWALAMBANA';
$_SESSION['find_url']='mis_swalambana.php';
?>
<html>
<head>
	<link rel="stylesheet" href="css/find.css">
<link rel="stylesheet" href="css/base.css">
 
<style type="text/css">
</style>
</head>
<body>
	
<?php include 'header.php';?>
 <?php include 'menu.php';?>
 <?php include 'find_body_with_date.php';?>
</body>
</html>

