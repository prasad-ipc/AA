<?php
session_start();
?>
<?php
$_SESSION['username'] = $_POST['user'];
$_SESSION['userpass'] = $_POST['pass'];
$_SESSION['authuser'] = 0;

//Check username and password information



if (($_SESSION['username'] == '123') and
    ($_SESSION['userpass'] == '123')) {
    $_SESSION['authuser'] = 1;
  echo '<style type="text/css">';
echo '.welcome{';
echo 'width:auto;';
  echo 'font-size: 15px;';
  echo 'background-color:brown;';
  echo 'color: #FFF;';
  echo ' text-align:right;';
  echo 'margin-bottom: -21px;';
echo '}';
echo '  </style>';
 echo '<p class="welcome">' . 'Hi Mr   ' . $_SESSION['username'] . '</p>';

} else {



  echo '<style type="text/css">';
echo '.warning{';
echo 'width:100%;';
  echo 'font-size: 40px;';
  echo 'background-color:Red;';
  echo 'color: white;';
  echo ' text-align: center;';
echo '}';
echo '  </style>';
    echo '<div class="warning">';
    echo 'Sorry Mr  ' . $_SESSION['username'] . ', you don\'t have permission to view this page!';
    echo '</div>';
    include "stop.php";
    exit();     
}
?>

<?php include 'manage.php'; ?>



<!--
 
 