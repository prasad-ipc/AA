
<style type="text/css">
#header{
	height: 80px;
background-color: #fff;
	background-image: url('images/header-bg.png');
	color: white;
	text-align: center;
width: auto;
}

</style>

<div id="header">
 <h1>DATA  MANAGEMENT </h1>
<?php
date_default_timezone_set('Asia/Kolkata');
echo date('F d');
echo ', ';
echo date('Y');
?>
 <br/>
</div>
