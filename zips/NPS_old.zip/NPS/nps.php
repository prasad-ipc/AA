<html>
<head>
<link rel="stylesheet" href="css/base.css">
<STYLE TYPE="text/css">
.mis_heading {
	position: static;
text-align: center;
font-size: 25px;
color: #FFF;
background-color:#4D0202;
padding: 12px 0PX 10PX 0PX;
margin-top: =12px; 	
 }

</STYLE>
</head>
<body>

<table>
  <tr>
    <th class="nps">Sl No</th>
    <th class="nps"> Emp ID</th>
    <th class="nps"> NPS CODE</th>
    <th class="nps">NPS Name</th>
    <th class="nps"> Contact No</th>
    <th class="nps"> Block</th>
    <th class="nps"> BC_Name</th>
    <th class="nps"> BC_ID</th>
    <th class="nps"> District</th>
    <th class="nps"> DC Name</th>
  
  
  

<?php include 'header.php'; ?>
<?php include 'menu.php';?>
<div class="mis_heading"> NPS DETAILS
	</div>
<?php

// Recives input from form.php
$dist=$_POST['selection'];
$dt=$_POST['date'];
$blk=$_POST['selection1'];
//Check for where string

if(!$dt){
                if ( $blk== 'ALL BLOCKS') {

                        if ($dist=='ALL DISTRICTS') {
                        # code...
                            
                            $diststring="";
                            } else {
                            # code...
                            
                            $diststring="where distco.dc_id = '$dist'";
                            }

                 } else {

                            if ($dist=='ALL DISTRICTS')  {
                                # code...
                                $diststring="where blockco.bc_id= '$blk'";
                                
                            } else {
                                 $diststring="where distco.dc_id = '$dist' AND blockco.bc_id= '$blk'";
                                    }  

                }

}else{

            if ( $blk== 'ALL BLOCKS') {

                    if ($dist=='ALL DISTRICTS') {
                    # code...
                        
                        $diststring="where areaco.emp_doj='$dt'";
                        } else {
                        # code...
                        
                        $diststring="where distco.dc_id = '$dist' AND areaco.emp_doj='$dt'";
                        }

             } else {

                        if ($dist=='ALL DISTRICTS')  {
                            # code...
                            $diststring="where blockco.bc_id= '$blk' AND areaco.emp_doj='$dt'";
                            
                        } else {
                             $diststring="where distco.dc_id = '$dist' AND blockco.bc_id= '$blk' AND areaco.emp_doj='$dt'";
                                }  

            }
}


//connect to MySQL
$db = mysql_connect('localhost', 'root', '') or 
    die ('Unable to connect. Check your connection parameters.');

//make sure our recently created database is the active one
mysql_select_db('NPS', $db) or die(mysql_error($db));

$query =	"SELECT 
			distco.district,distco.dc_name,distco.dc_id, blockco.block,blockco.bc_name,
      blockco.bc_id,areaco.nps_name,areaco.emp_id,areaco.contact_no,
      areaco.nps_id,areaco.emp_id,areaco.emp_doj,stateco.sc_id as state
		    
    FROM stateco   JOIN distco ON stateco.sc_id = distco.sc_id 
            JOIN  blockco ON distco.dc_id = blockco.dc_id
            JOIN  areaco ON blockco.bc_id = areaco.bc_id 
           $diststring
    			 order by dc_id,bc_id,nps_id";

$result=mysql_query($query, $db) or die(mysql_error($db)); 
    
// show the results




if(!$dt){
                if ( $blk== 'ALL BLOCKS') {

                        if ($dist=='ALL DISTRICTS') {
                        # code...
                            
                            echo '<p style="color:brown;text-align :center;font-size:20px">' .
                            "FOR " . $dist ." FOR ".$blk . "  TILL DATE ".   ' </p>';
                            } else {
                            # code...
                            
                           // $diststring="where distco.dc_id = '$dist'";
                                echo '<p style="color:brown;text-align :center;font-size:20px">' .
                            "FOR " . $dist ."  TILL DATE " . '
                             </p>';
                            }

                 } else {

                            if ($dist=='ALL DISTRICTS')  {
                                # code...
                                //$diststring="where blockco.bc_id= '$blk'";
                                echo '<p style="color:brown;text-align :center;font-size:20px">' .
                            "FOR " .$blk . "  TILL DATE " . '
                             </p>';
                                
                            } else {
                                // $diststring="where distco.dc_id = '$dist' AND blockco.bc_id= '$blk'";
                                    echo '<p style="color:brown;text-align :center;font-size:20px">' .
                            "FOR " . $dist ." FOR ".$blk . "  TILL DATE " . '
                             </p>';
                                    }  

                }

}else{

            if ( $blk== 'ALL BLOCKS') {

                    if ($dist=='ALL DISTRICTS') {
                    # code...
                        
                        //$diststring="where applications.date='$dt'";
                        echo '<p style="color:brown;text-align :center;font-size:20px">' .
                            "FOR " . $dist ." FOR ".$blk . "  FOR DATE " . $dt.'
                             </p>';
                        } else {
                        # code...
                        
                        //$diststring="where distco.dc_id = '$dist' AND applications.date='$dt'";
                            echo '<p style="color:brown;text-align :center;font-size:20px">' .
                            "FOR " . $dist ."  FOR DATE " . $dt.'
                             </p>';
                        }

             } else {

                        if ($dist=='ALL DISTRICTS')  {
                            # code...
                           // $diststring="where blockco.bc_id= '$blk' AND applications.date='$dt'";
                            echo '<p style="color:brown;text-align :center;font-size:20px">' .
                            "FOR " .$blk . "  FOR DATE " . $dt.'
                             </p>';
                        } else {
                             //$diststring="where distco.dc_id = '$dist' AND blockco.bc_id= '$blk' AND applications.date='$dt'";
                                echo '<p style="color:brown;text-align :center;font-size:20px">' .
                            "FOR " . $dist ." FOR ".$blk . "  FOR DATE " . $dt.'
                             </p>';
                                }  

            }
}














 $slno =0;
 
while ($row = mysql_fetch_array($result)) {
extract($row);

$slno = $slno+1;

   //  <th class="bc_name"> bc_name</th>
   // <th class="dc_name"> dc_name</th>
  //  <th class="remarks"> Remarks</th>
echo '<tr>';
echo '<td class="benf">' . $slno .'</td>';
echo '<td class="benf">' . $emp_id .'</td>';
echo '<td class="benf">' . $nps_id .'</td>';
echo '<td class="benf">' . $nps_name .'</td>';
echo '<td class="benf">' . $contact_no .'</td>';
echo '<td class="benf">' . $block .'</td>';
echo '<td class="benf">' . $bc_name .'</td>';
echo '<td class="benf">' . $bc_id .'</td>';
echo '<td class="benf">' . $district .'</td>';
echo '<td class="benf">' . $dc_name .'</td>';

echo '</tr>';

echo '<tr>';
//echo '<td>' . 'Total No Of Apllications =' .'</td>';
}

echo '</table>';
mysql_close($db);


?>

</body>
</html>
