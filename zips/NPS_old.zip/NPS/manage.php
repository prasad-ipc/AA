

<html>
<head>
<link rel="stylesheet" href="css/base.css">	
<title>NPS Management</title>
<?php include 'header.php'; ?>
 <?php include 'menu.php';?>
<style type="text/css">
#content{
	width: 100%;
	color: blue;
	font-size: 150px;
}
</style>
</head>
<body>

<DIV id="content">

<p>Main page content</p>
</DIV>
</body>
</html>