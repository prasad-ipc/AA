<?php
// define variables and set to empty values

$nps_id=$date=$nos="";
$nps_idErr=$dateErr=$nosErr="";


if (empty($_POST["nps_id"])) {
   $nps_idErr = "nps_id is required";
   
   //  $msg = "You left nps_id field empty.";
   // echo $msg;
  
   } else  {
   if (preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬]/', ($_POST["nps_id"]))) {
      $nps_idErr = "Only use characters and numbers";
       
   } else {

      $nps_id = test_input($_POST["nps_id"]);
      $nps_idErr="ok";
    }
  }

if ($_SERVER["REQUEST_METHOD"] == "POST") {
   if (empty($_POST["date"])) {
   $dateErr = "date is required";
   
   //  $msg = "You left date field empty.";
   // echo $msg;
  
   } else  {
   if(preg_match('/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/', $date)){ 
      $dateErr = "Enter date in YYYY-MM-DD format only";
       
   } else {

      $date = test_input($_POST["date"]);
      $dateErr="ok";
    }
  }



if (empty($_POST["nos"])) {
   
    $nosErr = "Nos is required";
   
   //  $msg = "You left nos field empty.";
   // echo $msg;
  
   } else  {
  if (preg_match('/([0-9]{1})/', $_POST["nos"])){
      $nos = test_input($_POST["nos"]);
      $nosErr="ok";

          } else {
      
      $nosErr = "Enter valid Number";
    }
  }

}


function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
?>


<!DOCTYPE HTML> 
<html>
<head>
   <link rel="stylesheet" href="css/base.css">
<style>

body{
  color: #757575;
}
.note {
  color: #FF0000;
text-align: right;
font-size: 25px;
}
.error {
  color: #FF0000;
  font-size: 25px;
}

table{
  width: 50%;
  margin-left: 25%;
}
tr,td{
  height: 35px;

}
.emp_heading {
    position: static;
text-align: center;
font-size: 25px;
color: #FFF;
background-color:#757575;
padding: 5px 2px 5px 2px;
margin-top: =12px;  
 }
</style>
</head>
<body> 
<?php include 'header.php'; ?>
<?php include 'menu.php';?>
<div class="emp_heading"> ADD NO OF APPLICATIONS DONE BY NPS
    </div>

<p class="note">* required field.</p>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> 
   
<table>
  <tr>
    <td> 
    NPS Code
    </td>
     <td>
    <input type="text" name="nps_id" value="<?php echo $nps_id;?>">
   <td><span class="error">*</span> <?php echo $nps_idErr;?></td>
  </td> 
</tr>  
  <tr>
    <td> 
      Date
    </td> 
    <td> 
     <input type="date" name="date" value="<?php echo $date;?>">
   <td><span class="error">*</span> <?php echo $dateErr;?></td>

    </td> 
</tr>  
<tr>
    <td> 
    Nos
    </td>
     <td>
    <input type="text" name="nos" value="<?php echo $nos;?>">
   <td><span class="error">*</span> <?php echo $nosErr;?></td>
   
 </td> 
</tr>  
<tr colspan='3'>
    
     <td>
   <input type="submit" name="submit" value="ADD"> 
 </td> 
</tr> 
</form>




</body>
</html>





<?php
if ($nps_idErr=="ok" && $dateErr=="ok"  && $nosErr=="ok") {
    $db = mysql_connect('localhost', 'root', '') or 
    die ('Unable to connect. Check your connection parameters.');

//make sure our recently created database is the active one
mysql_select_db('NPS', $db) or die(mysql_error($db));


$query = "INSERT INTO applications ( nps_id,`date`, nos)
VALUES ('$nps_id', '$date', '$nos')"; 
      
$result=mysql_query($query) or die(" insert error :".mysql_error());
echo "Successful";

  }

//mysql_close($db);
//exit;
?>


