<html>
<head>
<title>You are not Authorised User</title>
<style type="text/css">
.stop {
	width: 100%;
	height: 100%;
	background-color: red;
	font-size: 200px;
	color: white;
	text-align: center; 
}
</style>
</head>
<body>
<div class="stop">
	STOP
</div>
</body>