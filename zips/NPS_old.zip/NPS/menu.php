




<nav>
	<ul>
		<li><a href="home.php">Homek</a></li>
		<li><a href="">Reports</a>
			<ul>
				<li><a href="find_app.php">APPLICATIONS</a></li>
				
				
					<ul>
						<li><a href="#">aaaaaa</a></li>
						<li><a href="#">bbbb</a></li>
					</ul>
				</li>
			</ul>
		</li>
		<li><a href="#">Add</a>
			<ul>
				<li><a href="addbenf.php">Benf Details</a></li>
				<li><a href="addbenfnos.php">NPS daily statement</a></li>
			</ul>
		</li>
		<li><a href="find_mis.php">MIS</a></li>
		<li><a href="employees.php">EMPLOYEES</a>
			<ul>
				<li><a href="add_dc.php">ADD DC</a></li>
				<li><a href="add_bc.php">ADD BC</a></li>
				<li><a href="add_nps.php">ADD NPS</a></li>
				
			</ul>
		</li>		
		<li><a href="find_nps.php">FIND NPS</a>
	</ul>
</nav>
