<html>
<head>
	<link rel="stylesheet" href="css/base.css"> 
<style>
body{
	background-image: url("images/pattern.gif");
}
table {
	width: 100%;
	
}


</style>
</head>
<body>

<table>
  <tr>
   
    <th class="district"> District</th>
    <th class="district"> dc_name</th>
    <th class="district"> block</th>
    <th class="district"> bc_name</th>
    <th class="district"> mandal</th>
    <th class="district"> nps_name</th>
    <th class="district"> nps_id</th>
    <th class="district"> date</th>
    <th class="district"> nos</th>
  </tr>
<?php include 'header.php'; ?>
<?php include 'menu.php';?>

<?php
// Recives input from form.php
$dist=$_POST['selection'];
$dt=$_POST['date'];
$blk=$_POST['selection1'];
//Check for where string

if(!$dt){
                if ( $blk== 'ALL BLOCKS') {

                        if ($dist=='ALL DISTRICTS') {
                        # code...
                            
                            $diststring="";
                            } else {
                            # code...
                            
                            $diststring="where distco.dc_id = '$dist'";
                            }

                 } else {

                            if ($dist=='ALL DISTRICTS')  {
                                # code...
                                $diststring="where blockco.bc_id= '$blk'";
                                
                            } else {
                                 $diststring="where distco.dc_id = '$dist' AND blockco.bc_id= '$blk'";
                                    }  

                }

}else{

            if ( $blk== 'ALL BLOCKS') {

                    if ($dist=='ALL DISTRICTS') {
                    # code...
                        
                        $diststring="where applications.date='$dt'";
                        } else {
                        # code...
                        
                        $diststring="where distco.dc_id = '$dist' AND applications.date='$dt'";
                        }

             } else {

                        if ($dist=='ALL DISTRICTS')  {
                            # code...
                            $diststring="where blockco.bc_id= '$blk' AND applications.date='$dt'";
                            
                        } else {
                             $diststring="where distco.dc_id = '$dist' AND blockco.bc_id= '$blk' AND applications.date='$dt'";
                                }  

            }
}

$db = mysql_connect('localhost', 'root', '') or 
    die ('Unable to connect. Check your connection parameters.');

//make sure our recently created database is the active one
mysql_select_db('NPS', $db) or die(mysql_error($db));

$query =	"SELECT stateco.name as 'state_head',stateco.sc_id as state,
			distco.district, distco.dc_name, blockco.bc_id, blockco.dc_id,
			blockco.block,blockco.bc_name,areaco.mandal,areaco.nps_name,areaco.nps_id,
			applications.date,applications.nos 
    FROM stateco join distco ON stateco.sc_id = distco.sc_id 
    			 join blockco ON distco.dc_id = blockco.dc_id
    			 join areaco ON blockco.bc_id = areaco.bc_id 
    			 join applications ON areaco.nps_id = applications.nps_id
    			 $diststring
    			 order by dc_id,bc_id,nps_id";

$result=mysql_query($query, $db) or die(mysql_error($db)); 
    
// show the results
$total_records=0;
 $tnos =0;
 while ($row = mysql_fetch_array($result)) {
extract($row);

$tnos = $tnos+$nos;
 $total_records=$total_records+1;
 }



if(!$dt){
                if ( $blk== 'ALL BLOCKS') {

                        if ($dist=='ALL DISTRICTS') {
                        # code...
                            
                            echo '<p style="color:brown;text-align :center;font-size:20px">' .
                            "APPLICATIONS STATEMENT FOR " . $dist ." FOR ".$blk . "  TILL DATE " . 
                             " TOTAL NO OF APPLICATIONS  ". $tnos . '</p>';
                            } else {
                            # code...
                            
                           // $diststring="where distco.dc_id = '$dist'";
                                echo '<p style="color:brown;text-align :center;font-size:20px">' .
                            "APPLICATIONS STATEMENT FOR " . $dist ."  TILL DATE " . 
                             " TOTAL NO OF APPLICATIONS  ". $tnos . '</p>';
                            }

                 } else {

                            if ($dist=='ALL DISTRICTS')  {
                                # code...
                                //$diststring="where blockco.bc_id= '$blk'";
                                echo '<p style="color:brown;text-align :center;font-size:20px">' .
                            "APPLICATIONS STATEMENT FOR " .$blk . "  TILL DATE " . 
                             " TOTAL NO OF APPLICATIONS  ". $tnos . '</p>';
                                
                            } else {
                                // $diststring="where distco.dc_id = '$dist' AND blockco.bc_id= '$blk'";
                                    echo '<p style="color:brown;text-align :center;font-size:20px">' .
                            "APPLICATIONS STATEMENT FOR " . $dist ." FOR ".$blk . "  TILL DATE " . 
                             " TOTAL NO OF APPLICATIONS  ". $tnos . '</p>';
                                    }  

                }

}else{

            if ( $blk== 'ALL BLOCKS') {

                    if ($dist=='ALL DISTRICTS') {
                    # code...
                        
                        //$diststring="where applications.date='$dt'";
                        echo '<p style="color:brown;text-align :center;font-size:20px">' .
                            "APPLICATIONS STATEMENT FOR " . $dist ." FOR ".$blk . "  FOR DATE " . $dt.
                             " TOTAL NO OF APPLICATIONS  ". $tnos . '</p>';
                        } else {
                        # code...
                        
                        //$diststring="where distco.dc_id = '$dist' AND applications.date='$dt'";
                            echo '<p style="color:brown;text-align :center;font-size:20px">' .
                            "APPLICATIONS STATEMENT FOR " . $dist ."  FOR DATE " . $dt.
                             " TOTAL NO OF APPLICATIONS  ". $tnos . '</p>';
                        }

             } else {

                        if ($dist=='ALL DISTRICTS')  {
                            # code...
                           // $diststring="where blockco.bc_id= '$blk' AND applications.date='$dt'";
                            echo '<p style="color:brown;text-align :center;font-size:20px">' .
                            "APPLICATIONS STATEMENT FOR " .$blk . "  FOR DATE " . $dt.
                             " TOTAL NO OF APPLICATIONS  ". $tnos . '</p>';
                        } else {
                             //$diststring="where distco.dc_id = '$dist' AND blockco.bc_id= '$blk' AND applications.date='$dt'";
                                echo '<p style="color:brown;text-align :center;font-size:20px">' .
                            "APPLICATIONS STATEMENT FOR " . $dist ." FOR ".$blk . "  FOR DATE " . $dt.
                             " TOTAL NO OF APPLICATIONS  ". $tnos . '</p>';
                                }  

            }
}








//echo '<p style="color:brown;text-align :center;font-size:20px">' . "APPLICATIONS STATEMENT FOR " . $dist ." FOR ".$blk
//. "  ON " . $dt . ". ". " TOTAL NO OF APPLICATIONS  ". $tnos . '</p>';
 $tnos =0;
 echo 'Total records = '. $total_records;
//connect to MySQL 
$result=mysql_query($query, $db) or die(mysql_error($db)); 
while ($row = mysql_fetch_array($result)) {
extract($row);

$tnos = $tnos+$nos;
echo '<tr>';


echo '<td>' . $district .'</td>';

echo '<td>' . $dc_name .'</td>';
echo '<td>' . $block .'</td>';
echo '<td>' . $bc_name .'</td>';
echo '<td>' . $mandal .'</td>';
echo '<td>' . $nps_name .'</td>';
echo '<td>' . $nps_id .'</td>';
echo '<td>' . $date .'</td>';
echo '<td>' . $nos .'</td>';
echo '</tr>';
}
echo '<tr>';
echo '<td>' . 'Total No Of Apllications =' .'</td>';
echo '<td>' . $tnos .'</td>';

echo '</table>';
mysql_close($db);
echo "Success";

?>
<?php echo 'Total records = '. $total_records;?>
</body>
</html>
