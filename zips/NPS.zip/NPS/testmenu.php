




<nav>
	<ul>
		<li><a href="#">Home</a></li>
		<li><a href="">Reports</a>
			<ul>
				<li><a href="district.php">DC</a></li>
				<li><a href="block.php">BC</a></li>
				<li><a href="nps.php">NPS</a>
					<ul>
						<li><a href="#">HTML</a></li>
						<li><a href="#">CSS</a></li>
					</ul>
				</li>
			</ul>
		</li>
		<li><a href="#">Articles</a>
			<ul>
				<li><a href="#">Web Design</a></li>
				<li><a href="#">User Experience</a></li>
			</ul>
		</li>
		<li><a href="#">Inspiration</a></li>
	</ul>
</nav>
