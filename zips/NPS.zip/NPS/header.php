	
<link rel="stylesheet" href="css/base.css">	
<div id="header">
 HOSTGOD DATA MANAGEMENT SERVICES
<?php
/*date_default_timezone_set('Asia/Kolkata');
echo date('F d');
echo ', ';
echo date('Y');*/
?>
</div>
