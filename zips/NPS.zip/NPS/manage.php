<html>
<head>
	
<link rel="stylesheet" href="css/base.css">	
<title>NPS Management</title>
<?php include 'header.php'; ?>
 <?php include 'menu.php';?>
<style type="text/css">
 body {
    width=100%;
    height: 100%;
    background-image: url(../images/clouds-in-blue-sky.jpg);
    
    background:#eee;
    margin:0;
    padding:0;
}

p{
text-align:center;
font-size:150px;
color: white;
    text-align: center;
    text-shadow:0 5px 5px rgba(0,0,0, 10);
}

	
#content{
	width: 100%;
	color: blue;
	font-size: 150px;
}
</style>
</head>
<body>

<DIV id="content">

<p>HOSTGOD</p>
</DIV>
</body>
</html>