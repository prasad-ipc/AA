<?Php
if(!(isset($_SESSION['authuser']) and strlen($_SESSION['authuser']) > 2)){
echo "Please <a href=index.php>login</a> to use this page ";
echo "stop()";
}
?>